package sayHello;

public interface Person {
    String getName();
    String sayHello();

}
