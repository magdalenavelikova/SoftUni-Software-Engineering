package carShopExtend;

public interface Sellable extends Car {
    Double getPrice();
}
