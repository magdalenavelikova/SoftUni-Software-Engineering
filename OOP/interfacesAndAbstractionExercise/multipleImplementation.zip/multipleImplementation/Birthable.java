package multipleImplementation;

public interface Birthable {
    String getBirthDate();
}
