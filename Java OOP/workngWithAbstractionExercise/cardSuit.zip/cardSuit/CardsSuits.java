package workngWithAbstractionExercise.cardSuit;

public enum CardsSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
