package militaryElite;

import java.util.List;

public interface LieutenantGeneral extends Soldier {
    public List<PrivateImpl> getPrivatesImpl();
}
