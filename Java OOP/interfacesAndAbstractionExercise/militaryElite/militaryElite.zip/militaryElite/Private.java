package militaryElite;

public interface Private extends Soldier {
    public double getSalary();
}
