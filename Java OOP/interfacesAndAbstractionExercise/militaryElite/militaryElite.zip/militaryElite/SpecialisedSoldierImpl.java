package militaryElite;

public enum SpecialisedSoldierImpl {
    Airforces,
    Marines;


}
