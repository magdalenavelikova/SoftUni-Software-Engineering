package militaryElite;



public enum State {
    inProgress,
    finished;




}
