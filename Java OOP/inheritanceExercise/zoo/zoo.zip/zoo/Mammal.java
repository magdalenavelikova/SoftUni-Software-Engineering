package zoo;

public class Mammal extends Animal{
    public Mammal(String name) {
        super(name);
    }
}
