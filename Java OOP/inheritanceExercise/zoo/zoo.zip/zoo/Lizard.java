package zoo;

public class Lizard extends Reptile{
    public Lizard(String name) {
        super(name);
    }
}
