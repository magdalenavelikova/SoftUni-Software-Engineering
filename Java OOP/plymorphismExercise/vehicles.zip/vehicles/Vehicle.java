package vehicles;

public interface Vehicle {
    abstract String drive(Double distance);
    abstract void refuel(Double litters);
}
