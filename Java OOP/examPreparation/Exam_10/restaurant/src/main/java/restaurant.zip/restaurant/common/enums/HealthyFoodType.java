package restaurant.common.enums;

public enum HealthyFoodType {
    Salad,
    VeganBiscuits
}
